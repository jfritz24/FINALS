<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
</head>
<body>
    <center>
    <h1>Registration</h1>

    <form action="" method="POST">
        <label>FirstName:</label> </br>
        <input type="text" name="FIRST_NAME" required> </p>
        
        <label>LastName:</label> </br>
        <input type="text" name="LAST_NAME" required> </p>
        
        <label>Email:</label> </br>
        <input type="email" name="EMAIL" required> </p>

        <label>Password:</label> </br>
        <input type="password" name="PASS" required> </p>

        <input type="submit" name="reg_button" value="Register">


</center>


    </form>

    <p><a href="Register.php"> Register Here! </a> </p>

</body>
</html>