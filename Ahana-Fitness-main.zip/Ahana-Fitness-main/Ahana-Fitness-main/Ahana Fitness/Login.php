<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign in</title>
</head>
<body>

    <h1>Sign In</h1>

    <form action="process.php" method="POST">

    <label>Email</label>
    <input type="email" name="LOGIN_email" required placeholder="Enter email here">
    <br></br>

    <label>Password</label>
    <input type="password" name="LOGIN_pass" placeholder="Enter password here">
    <br></br>

    <input type="submit" name="login" value="Log in">

</form>

<p><a href="Register.php"> Log in Here! </a> </p>


</body>
</html>