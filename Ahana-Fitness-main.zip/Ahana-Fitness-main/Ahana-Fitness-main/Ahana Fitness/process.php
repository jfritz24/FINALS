<?php

    include "conn.php";
    session_start();
    
    // this code for registration
    if(isset($_POST['reg_button'])){

        $firstname=$_POST['FIRST_NAME'];
        $lastname=$_POST['LAST_NAME'];
        $email=$_POST['EMAIL'];
        $password=$_POST['PASS'];

        $insertusers=mysqli_query($conn, "INSERT INTO users VALUES('0','$firstname','$lastname','$email','$password')")
  
        if($insertusers==true){
            
            ?>
            <script>
                alert("Registered Successfully");
                window.location.href="index.php";
            </script>

            <?php
    
        }else{

            ?>
            <script>
                alert("Failed to register try again");
                window.location.href="Register.php";
            </script>

            <?php
        }

  
    }

    //this code for log in

    if(isset($_POST['login'])){

        $email=$_POST['LOGIN_email'];
        $password=$_POST['LOGIN_pass'];

        $check=mysqli_query($conn, "SELECT * FROM users WHERE email='$EMAIL' AND password='$PASS' ");

        $num=mysqli_num_rows($check);

        if($num >= ){
            $_SESSION['email']=$email;
            ?>
            <script>
                alert("Log in Successful!");
                window.location.href="";
            </script>

            <?php
        }else{

            ?>
            <script>
                alert("Log in Failed");
                window.location.href="index.php";
            </script>

            <?php
        
        }

    }

?>