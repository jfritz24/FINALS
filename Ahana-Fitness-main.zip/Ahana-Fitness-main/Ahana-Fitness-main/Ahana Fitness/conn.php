<?php

    $conn = mysqli_connect("localhost", "root", "");

    if($conn==TRUE){
        echo "DB Server connected";
    }else{
        echo "DB Server failed to connect";
    }


?>